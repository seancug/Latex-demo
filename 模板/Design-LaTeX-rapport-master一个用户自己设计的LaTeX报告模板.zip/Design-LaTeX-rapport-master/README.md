# Design-LaTeX-rapport
Template d'un design de rapport

* Mettre le fichier .sty dans votre répertoire local de votre distribution LaTeX dans un dossier Rapport2 ;
* mettre ensuite les fichiers des headers (le logo et headtitre.tex) dans le répertoire local dans un dossier headtitre ;
* voir template pour utilisation.


# Répertoire LaTeX local et installation

* Ouvrez votre terminal ou invite des commandes ;
* tapez `kpsewhich -var-value=TEXMFHOME` (pour savoir où est le répetoire local de votre installation LaTeX) ;
* allez dans le dossier donné, puis dans tex, dans latex et créez les dossiers Rapport2 et headtitre ;
* mettez les fichiers correspondants.
    
